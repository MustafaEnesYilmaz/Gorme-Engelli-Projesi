#define TRIG_PIN 9
#define ECHO_PIN 10
#define VIBRATION_PIN 6

void setup() {
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(VIBRATION_PIN, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  long duration;
  float distance;

  // Ultrasonik sensör tetikleme
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  // Mesafeyi ölç
  duration = pulseIn(ECHO_PIN, HIGH);
  distance = duration * 0.034 / 2;

  Serial.print("Mesafe: ");
  Serial.print(distance);
  Serial.println(" cm");

  // Eğer mesafe 50 cm'den küçükse titreşimi başlat
  if (distance < 50) {
    // 0 cm - 50 cm arası mesafe --> titreşim hızı artsın
    int delayTime = map(distance, 0, 50, 50, 500); // mesafe azalınca delay azalır
    digitalWrite(VIBRATION_PIN, HIGH);
    delay(delayTime);
    digitalWrite(VIBRATION_PIN, LOW);
    delay(delayTime);
  } else {
    digitalWrite(VIBRATION_PIN, LOW); // titreşim kapalı
  }

  delay(100);
}
